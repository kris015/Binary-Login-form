<?php
// Uključivanje fajla za povezivanje sa bazom podataka
require_once "inc/db.php";

// Provera da li su korisničko ime i lozinka prosleđeni iz forme
if(isset($_POST['username']) && isset($_POST['password'])) {
    // Dobijanje korisničkog imena i lozinke iz forme
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Provera korisničkog imena i lozinke u bazi podataka
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    // Provera rezultata upita
    if(mysqli_num_rows($result) == 1) {
        // Korisnik je uspešno ulogovan, redirekcija na pocetna.php
        header("Location: pocetna.php");
        exit(); // Zaustavljanje daljeg izvršavanja skripte nakon redirekcije
    } else {
        // Korisničko ime ili lozinka nisu tačni, ispis poruke o grešci
        echo "Greška u imenu ili šifri!";
    }
} else {
    // Ako korisničko ime ili lozinka nisu prosleđeni iz forme, ispis poruke o grešci
    echo "Molimo unesite korisničko ime i lozinku!";
}
?>
