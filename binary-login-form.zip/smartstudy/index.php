<?php
// Uključivanje fajla za povezivanje sa bazom podataka
require_once "inc/db.php";

// Provera da li je forma poslata
if(isset($_POST['username'], $_POST['password'])) {
    // Dobijanje korisničkog imena iz forme
    $username = $_POST['username'];

    // Provera korisničkog imena u bazi podataka
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Provera rezultata upita
    if($result->num_rows == 1) {
        // Korisnik postoji u bazi, provera lozinke
        $user = $result->fetch_assoc();
        if(password_verify($_POST['password'], $user['password'])) {
            // Lozinka je tačna, korisnik je uspešno ulogovan, redirekcija na pocetna.php
            header("Location: pocetna.php");
            exit(); // Zaustavljanje daljeg izvršavanja skripte nakon redirekcije
        } else {
            // Lozinka nije tačna, ispis poruke o grešci
            $error_message = "Greška u imenu ili šifri!";
        }
    } else {
        // Korisnik ne postoji u bazi, ispis poruke o grešci
        $error_message = "Greška u imenu ili šifri!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartStudy - Online learning platform</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('pozadina.gif');
            background-size: cover;
            background-position: center;
            color: #00ff00;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #1e1e1e;
            /*background-color: rgba(30, 30, 30, 0.7); - transparentna/providna boja*/
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 20px rgba(0, 255, 0, 0.5);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }

        h2 {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"],
        input[type="submit"] {
            width: calc(100% - 30px);
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            background-color: #333;
            color: white;
            border-radius: 5px;
            outline: none;
        }

        input[type="text"] {
            color:#00cc00;
        }

        input[type="password"] {
            color:#00cc00;
        }

        input[type="submit"] {
            background-color: #00ff00;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #00cc00;
            color:black;
        }

        label {
            display: block;
            text-align: left;
        }

        input[type="text"]::placeholder,
        input[type="password"]::placeholder {
            color: #666;
        }
    </style>
</head>

<body>

    <div class="container">
        <h2>Sign In</h2>
        <form action="submit_form.php" method="post">
            <div class="inputBox">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="inputBox">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="inputBox">
                <input type="submit" value="Login">
            </div>
        </form>
    </div>

</body>

</html>
