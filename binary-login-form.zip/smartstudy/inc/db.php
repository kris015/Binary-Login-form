<?php
// Podaci za povezivanje na MySQL bazu
$servername = "localhost"; // Ako je baza na istom serveru kao i PHP skripta, obično je "localhost"
$username = "root"; // Korisničko ime za pristup bazi podataka
$password = ""; // Lozinka za pristup bazi podataka
$database = "smartstudy"; // Ime baze podataka

// Kreiranje konekcije
$conn = new mysqli($servername, $username, $password, $database);

// Provera konekcije
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo ""; // Ovo možete ukloniti, ili zameniti sa odgovarajućom porukom
}

// Zatvaranje konekcije (nije obavezno, jer će se konekcija automatski zatvoriti na kraju izvršenja skripte)
$conn->close();
?>
